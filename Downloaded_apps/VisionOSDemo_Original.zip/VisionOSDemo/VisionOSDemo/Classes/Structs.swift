//
//  Structs.swift
//  VisionOSDemo
//
//  Created by Ravi Jadav on 08/03/24.
//

import Foundation

struct HomeCategory {
    
    var category_name: String = ""
    var isSelected: Bool = false
}
