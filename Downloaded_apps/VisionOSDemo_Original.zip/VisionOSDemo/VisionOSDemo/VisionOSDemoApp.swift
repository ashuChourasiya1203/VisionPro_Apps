//
//  VisionOSDemoApp.swift
//  VisionOSDemo
//
//  Created by Ravi Jadav on 08/03/24.
//

import SwiftUI

@main
struct VisionOSDemoApp: App {
    
    @StateObject var pilot = UIPilot(initial: AppRoute.landingView)
//    @StateObject private var appRootManager = AppRootManager()
        
    var body: some Scene {
        WindowGroup {
//            Group {
//                switch appRootManager.currentRoot {
//                case .landing: LandingView().frame(minWidth: 1280, maxWidth: 1280, minHeight: 867, maxHeight: 867)
//                case .register: RegisterView()
//                case .home: HomeView()
//                case .artist: ArtistView().frame(minWidth: 1280, maxWidth: 1280, minHeight: 867, maxHeight: 867)
//                }
//            }
//            .environmentObject(appRootManager)
//            LandingView()
//                .frame(minWidth: 1280, maxWidth: 1280, minHeight: 867, maxHeight: 867)
            UIPilotHost(pilot) { route in
                switch route  {
                case .landingView: LandingView().frame(minWidth: 1520, maxWidth: 1520, minHeight: 867, maxHeight: 867)
                case .registerView: RegisterView()
                case .homeview: HomeView()
                case .artistView: ArtistView()
                }
            }
//            .glassBackgroundEffect(displayMode: .never)
        }
        .windowStyle(.plain)
        .windowResizability(.contentSize)
//        .defaultSize(width: 0.5, height: 0.5, depth: 0.0, in: .meters)
//        .windowResizability(.contentMinSize)
//        .defaultSize(CGSize(width: 1200, height: 1100))
        
        
        //        ImmersiveSpace(id: "ImmersiveSpace") {
        //            ImmersiveView()
        //        }
    }
}


final class AppRootManager: ObservableObject {
    
    @Published var currentRoot: eAppRoots = .landing
    
    enum eAppRoots {
        case landing
        case register
        case home
        case artist
    }
}
